export interface FormData {
  destination: string;
  dates: string;
  duration: string;
  interests: string;
  additionalInfo: string;
}